package com.example.daftarpemainbola;

import java.util.ArrayList;

public class BolaData {
    public static String[][] data = new String[][]{
            {"Steven Gerrard", "Legenda Liverpool FC", "https://upload.wikimedia.org/wikipedia/commons/a/aa/Steven_Gerrard_in_2014.jpg"},
            {"Carles Puyol", "Legenda FC Barcelona", "https://upload.wikimedia.org/wikipedia/commons/6/60/Carles_Puyol_Joan_Gamper-Tr.jpg"},
            {"Alessandro Del Piero", "Legenda Juventus FC", "https://upload.wikimedia.org/wikipedia/commons/b/b7/Alessandro_Del_Piero_2008_cropped.jpg"},
            {"Roberto Carlos", "Legenda Real Madrid CF", "https://upload.wikimedia.org/wikipedia/commons/5/53/Roberto_Carlos_2011.jpg"},
            {"David Beckham", "Legenda Manchester United FC", "https://upload.wikimedia.org/wikipedia/commons/7/7b/David_Beckham_Nov_11_2007.jpg"},
            {"Juninho Pernambucano", "Legenda Olympique Lyon", "https://upload.wikimedia.org/wikipedia/commons/7/73/Juninho_wikipedia.jpg"},
            {"Philipp Lahm", "Legenda FC Bayern Muenchen", "https://upload.wikimedia.org/wikipedia/commons/e/ee/Philipp_Lahm%2C_Germany_national_football_team_%2804%29.jpg"}
    };

    public static ArrayList<Bola> getListData(){
        Bola bola = null;
        ArrayList<Bola> list = new ArrayList<>();
        for (String[] aData : data) {
            bola = new Bola();
            bola.setName(aData[0]);
            bola.setRemarks(aData[1]);
            bola.setPhoto(aData[2]);

            list.add(bola);
        }

        return list;
    }
}
